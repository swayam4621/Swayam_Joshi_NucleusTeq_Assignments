import re

EMAIL_PATTERN = re.compile(r"^[\w\.\-]+@[\w\-]+\.[a-zA-Z]{2,}$")
PHONE_PATTERN = re.compile(r"^\d{3}-\d{4}$")


def is_valid_email(email: str) -> bool:
    """validate email address using regex"""
    if not email:
        return False
    return bool(EMAIL_PATTERN.match(email))


def is_valid_phone(phone: str) -> bool:
    """validate ph no in the form 555-0101"""
    if not phone:
        return False
    return bool(PHONE_PATTERN.match(phone))


def clean_name(raw_name: str) -> str:
    """Basic cleaning"""
    return raw_name.strip().title()


def filter_members_by_domain(members, domain):
    """use filter() + lambda to select members whose email ends with a given domain
    """
    return list(filter(lambda m: m.email.endswith(domain), members))


def get_all_names(members):
    """Use map() + lambda to extract names from member objects"""
    return list(map(lambda m: m.name, members))