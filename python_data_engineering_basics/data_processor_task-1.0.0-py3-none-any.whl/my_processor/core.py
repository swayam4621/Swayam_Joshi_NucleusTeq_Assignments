from .utils import is_valid_email, is_valid_phone, clean_name


class InvalidMemberDataError(Exception):
    """Custom exception raised when member data fails validation"""

    def __init__(self, member_name: str, message: str = "Invalid member data"):
        self.member_name = member_name
        self.message = f"Invalid data for member '{member_name}': {message}"
        super().__init__(self.message)


class Member:
    """single member profile"""

    def __init__(self, name: str, email: str, phone: str):
        if not name or not name.strip():
            raise InvalidMemberDataError(name or "Unknown", "missing name")

        self.name = clean_name(name)

        if not is_valid_email(email):
            raise InvalidMemberDataError(self.name, f"invalid email '{email}'")
        self.email = email

        if not is_valid_phone(phone):
            raise InvalidMemberDataError(self.name, f"invalid phone '{phone}'")
        self.phone = phone

    def __str__(self):
        return f"Member(name={self.name}, email={self.email}, phone={self.phone})"

    def __repr__(self):
        return self.__str__()


def process_raw_member(raw: dict) -> Member:
    """
    Function that validates and constructs a Member from a raw dict
    Raises InvalidMemberDataError or KeyError
    """
    try:
        name = raw["name"]
        email = raw["email"]
        phone = raw["phone"]
    except KeyError as e:
        raise InvalidMemberDataError(raw.get("name", "Unknown"), f"missing field {e}")

    return Member(name, email, phone)