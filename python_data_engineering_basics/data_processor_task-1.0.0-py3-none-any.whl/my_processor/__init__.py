"""my_processor package small member data processing utility"""

from .core import Member, InvalidMemberDataError

__all__ = ["Member", "InvalidMemberDataError"]