# Data Processor Task

A small member-data validation utility built for the Python Core Concepts training.

## Features
- Dictionary/List based member storage
- Regex validation for email and phone
- Custom `InvalidMemberDataError` exception
- `Member` class (OOP)
- `filter()`/`map()` with lambdas for functional filtering

## Usage
```bash
python -m venv venv
source venv/bin/activate      # venv\Scripts\activate on Windows
pip install setuptools wheel
python setup.py sdist bdist_wheel
pip install dist/data_processor_task-1.0.0-py3-none-any.whl
python main.py
```

## Screenshots of outputs in terminal
### Running main.py
![Running main.py](screenshots/Screenshot%202026-08-10%20134031.png)

### Importing the package from dist folder
![Import from wheel](screenshots/image.png)

### Project structure & .whl file in dist/
![Project structure and .whl file locaation](screenshots/image2.png)