from my_processor.core import process_raw_member, InvalidMemberDataError
from my_processor.utils import filter_members_by_domain

raw_members = [
    {"name": "Swayam Joshi", "email": "swayam.joshi@example.com", "phone": "555-0101"},
    {"name": "Nathan smith", "email": "nathan.smith@...com", "phone": "555-0102"},
    {"name": "InvalidData", "email": "not-an-email", "phone": "555-0103"},
]


def main():
    processed = []
    error_count = 0

    for raw in raw_members:
        name = raw.get("name", "Unknown")
        print(f"Processing member: {name}...", end=" ")
        try:
            member = process_raw_member(raw)
            processed.append(member)
            print("Validation Successful.")
        except InvalidMemberDataError as e:
            error_count += 1
            print(f"\nError: Invalid email for member '{name}'. Skipping.")
        except Exception as e:
            error_count += 1
            print(f"\nUnexpected error for '{name}': {e}")

    print(f"\nSummary: {len(processed)} members processed successfully.")
    if error_count:
        print(f"{error_count} member(s) skipped due to errors.")

    example_domain_matches = filter_members_by_domain(processed, "example.com")
    print("\nMembers with @example.com email:")
    for m in example_domain_matches:
        print(f"  - {m}")


if __name__ == "__main__":
    main()